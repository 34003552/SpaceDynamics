package symbolicvalues.spacedynamics.activities

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Canvas
import android.media.MediaPlayer
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.view.GestureDetectorCompat
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.core.GameEngine
import symbolicvalues.spacedynamics.managers.OrientationManager
import symbolicvalues.spacedynamics.managers.toPauseActivity

/**
 * L'activité de jeu
 * @author Jean-Emile PELLIER
 */
class PlayGameActivity : AppCompatActivity() {
    private lateinit var mGameBoardView: GameBoardView

    // le détecteur de gestes
    private lateinit var mGestureDetector: GestureDetectorCompat
    // le gestionnaire d'orientation
    private lateinit var mOrientationManager: OrientationManager
    // le lecteur multimédia
    private lateinit var mMediaPlayer: MediaPlayer

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // verrouille l'orientation de l'écran
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED

        setContentView(R.layout.activity_play_game)

        mGameBoardView = findViewById(R.id.gameBoard)

        // initialise le détecteur de gestes
        mGestureDetector = GestureDetectorCompat(applicationContext, object : GestureDetector.OnGestureListener {
            override fun onShowPress(e: MotionEvent?) { }
            override fun onSingleTapUp(e: MotionEvent?) = true
            override fun onDown(e: MotionEvent?) = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent?, velocityX: Float, velocityY: Float) = true
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent?, distanceX: Float, distanceY: Float) = true
            override fun onLongPress(e: MotionEvent?) { }
        })
        // définit l'écouteur pour le double tap
        mGestureDetector.setOnDoubleTapListener(object : GestureDetector.OnDoubleTapListener {
            override fun onDoubleTap(e : MotionEvent): Boolean {
                this@PlayGameActivity.toPauseActivity()
                return true
            }
            override fun onDoubleTapEvent(e: MotionEvent?) = true
            override fun onSingleTapConfirmed(e: MotionEvent?) = true
        })

        // initialise le gestionnaire d'orientation
        mOrientationManager = OrientationManager()

        // initialise le lecteur multimédia
        mMediaPlayer = MediaPlayer.create(applicationContext, R.raw.blue_dream)
        mMediaPlayer.setOnCompletionListener{mp : MediaPlayer -> mp.start()}

        // démarre le moteur de jeu
        mGameBoardView.mGameEngine.start()
    }

    /**
     * Méthode appelée lors de la destruction de l'activité
     */
    override fun onDestroy() {
        super.onDestroy()
        // interrompt le moteur de jeu
        mGameBoardView.mGameEngine.stop()
        // détruit le lecteur multimédia
        mMediaPlayer.release()
    }

    /**
     * Méthode appelée lors de la détection d'un évènement tactile
     * @param event l'évènement tactile détecté
     */
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // transmet l'évènement tactile au détecteur de gestes
        mGestureDetector.onTouchEvent(event)

        return super.onTouchEvent(event)
    }

    /**
     * Méthode appelée lors de la reprise de l'activité
     */
    override fun onResume() {
        super.onResume()
        // relance le moteur de jeu
        mGameBoardView.mGameEngine.resume()
        // démarre l'écoute d'évènements d'orientation
        mOrientationManager.registerListener()
        // démarre le lecteur multimédia
        mMediaPlayer.start()
    }

    /**
     * Méthode appelée lors de la mise en pause de l'activité
     */
    override fun onPause() {
        super.onPause()
        // interrompt le moteur de jeu
        mGameBoardView.mGameEngine.pause()
        // annule l'écoute d'évènement d'orientation
        mOrientationManager.unregisterListener()
        // met en pause le lecteur multimédia
        mMediaPlayer.pause()
    }

    /**
     * La vue du plateau de jeu
     * @param context le contexte dans lequel se trouve la vue
     * @param attrs les attributs d'inflate
     * @param defStyle un attribut dans le thème courant
     */
    class GameBoardView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
    ) : View(context, attrs, defStyle) {
        // le moteur de jeu
        val mGameEngine: GameEngine

        init {
            // récupère les paramètres de la vue
            val a = context.obtainStyledAttributes(attrs, R.styleable.GameBoardView, defStyle, 0)
            a.recycle()
            // initialise le moteur de jeu
            mGameEngine = GameEngine(this@GameBoardView)
        }

        /**
         * Méthode appelée lors du dessin de la vue
         * @param canvas le paramètre canvas
         */
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            // détermine les constantes de dessin
            val contentWidth = width - paddingLeft - paddingRight
            val contentHeight = height - paddingTop - paddingBottom
            // dessine le moteur de jeu
            mGameEngine.draw(canvas, paddingLeft - paddingRight + width / 2,
                paddingTop - paddingBottom + height / 2, contentWidth, contentHeight)
        }
    }
}