package symbolicvalues.spacedynamics.managers

import android.content.Intent
import symbolicvalues.spacedynamics.activities.*
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser

/**
 * Le gestionnaire de navigation entre activités
 * @author Jean-Emile PELLIER
 */

/* La navigation à partir de MainMenuActivity */

fun MainMenuActivity.toPlayGameActivity() {
    CurrentUser.clear()
    val intent = Intent(this, PlayGameActivity::class.java)
    this.startActivity(intent)
}
fun MainMenuActivity.toLoadGameActivity() {
    val intent = Intent(this, LoadGameActivity::class.java)
    this.startActivity(intent)
}
fun MainMenuActivity.toShowScoresActivity() {
    val intent = Intent(this, ShowScoresActivity::class.java)
    this.startActivity(intent)
}

/* La navigation à partir de PlayGameActivity */

fun PlayGameActivity.toPauseActivity() {
    val intent = Intent(this, PauseActivity::class.java)
    this.startActivity(intent)
}
fun PlayGameActivity.toEndGameActivity() {
    val intent = Intent(this, EndGameActivity::class.java)
    this.startActivity(intent)
    this.finish()
}

/* La navigation à partir de PauseActivity */

fun PauseActivity.toSaveGameActivity() {
    val intent = Intent(this, SaveGameActivity::class.java)
    this.startActivity(intent)
}
fun PauseActivity.toMainMenuActivity() {
    val intent = Intent(this, MainMenuActivity::class.java)
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
    this.startActivity(intent)
}

/* La navigation à partir de EndGameActivity */

fun EndGameActivity.toMainMenuActivity() {
    val intent = Intent(this, MainMenuActivity::class.java)
    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
    this.startActivity(intent)
}

/* La navigation à partir de SaveGameActivity */

fun SaveGameActivity.toCameraActivity() {
    val intent = Intent(this, CameraActivity::class.java)
    this.startActivity(intent)
}

/* La navigation à partir de LoadGameActivity */

fun LoadGameActivity.toPlayGameActivity() {
    val intent = Intent(this, PlayGameActivity::class.java)
    this.startActivity(intent)
}

/* La navigation à partir de ShowScoresActivity */

fun ShowScoresActivity.toMapsActivity(selectedScore: Int) {
    val intent = Intent(this, MapsActivity::class.java)
    intent.putExtra("selectedScore", selectedScore)
    this.startActivity(intent)
}