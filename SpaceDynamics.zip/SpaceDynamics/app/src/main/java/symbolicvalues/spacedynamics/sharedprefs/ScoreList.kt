package symbolicvalues.spacedynamics.sharedprefs

import com.google.android.gms.maps.model.LatLng
import symbolicvalues.spacedynamics.core.Score
import java.lang.StringBuilder
import java.util.*

/**
 * La liste partagée contenant les scores
 * @author Jean-Emile PELLIER
 */
object ScoreList : SharedList<Score>("ScoreList",
    Comparator { s1, s2 ->
        if (s1.time != s2.time)  s1.time.compareTo(s2.time)
        else s1.nickname!!.compareTo(s2.nickname!!)
    },
    Comparator { s1, s2 -> s1.time.compareTo(s2.time) }) {

    /**
     * Construit des données brutes à partir de données stucturées
     * @param data une donnée structurée
     */
    override fun buildRawData(data: Score): String {
        val sb = StringBuilder()
        // ajoute le temps de jeu
        sb.append("${data.time}\n")
        // ajoute le pseudo
        sb.append("${data.nickname}\n")
        // ajoute la date
        sb.append("${mDateFormat.format(data.date)}\n")
        // ajoute la localisation géographique
        sb.append("${data.location!!.latitude}\n${data.location!!.longitude}")
        // assemble les données brutes
        return sb.toString()
    }

    /**
     * Construit des données abstraites à partir de données brutes
     * @param value une donnée brute
     */
    override fun parseRawData(data: String): Score {
        val scanner = Scanner(data)
        // récupère le temps de jeu
        val time = scanner.nextLine()
        // récupère le pseudo
        val nickname = scanner.nextLine()
        // récupère la date
        val date = scanner.nextLine()
        // récupère la localisation géographique
        val location = LatLng(scanner.nextLine().toDouble(), scanner.nextLine().toDouble())

        scanner.close()
        // construit le score
        return Score(time.toLong(), nickname, mDateFormat.parse(date), location)
    }
}