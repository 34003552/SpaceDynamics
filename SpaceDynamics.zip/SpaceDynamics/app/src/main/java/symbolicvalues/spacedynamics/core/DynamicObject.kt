package symbolicvalues.spacedynamics.core

import android.support.annotation.CallSuper

/**
 * Un objet dynamique implémentant Runnable
 * @author Jean-Emile PELLIER
 */
abstract class DynamicObject : Runnable {
    // l'état d'éxécution de l'objet
    @Volatile private var mRunning: Boolean = false
    // l'état de pause de l'objet
    @Volatile private var mPaused: Boolean = false

    // le verrou pour le démarrage
    private val mStartLock = Object()
    // le verrou pour la pause
    private val mPauseLock = Object()

    init {
        // démarre un thread daemon dédié à l'objet
        val thread = Thread(this@DynamicObject)
        thread.isDaemon = true
        thread.start()
    }

    /**
     * La méthode d'éxécution de l'objet
     */
    final override fun run() {
        try {
            // attend l'appel à la méthode 'start'
            synchronized(mStartLock) { mStartLock.wait() }
            while (mRunning) {
                // si appel à la méthode 'pause', attend l'appel à la methode 'resume'
                if (mPaused) synchronized(mPauseLock) { mPauseLock.wait() }
                // appel à la méthode de bouclage
                loop()
            }
        } catch(e: InterruptedException) {}
    }

    /**
     * La méthode de bouclage de l'objet
     */
    abstract fun loop()

    /**
     * Démarre le bouclage de l'objet
     */
    @CallSuper open fun start() {
        mRunning = true
        synchronized(mStartLock) { mStartLock.notify() }
    }

    /**
     * Met en pause le bouclage de l'objet
     */
    @CallSuper open fun pause() {
        mPaused = true
    }

    /**
     * Reprend le bouclage de l'objet
     */
    @CallSuper open fun resume() {
        mPaused = false
        synchronized(mPauseLock) { mPauseLock.notify() }
    }

    /**
     * Interrompt le bouclage de l'objet
     */
    @CallSuper open fun stop() {
        mRunning = false
    }
}