package symbolicvalues.spacedynamics.managers

import android.os.Environment
import symbolicvalues.spacedynamics.Logd
import symbolicvalues.spacedynamics.core.Save
import symbolicvalues.spacedynamics.sharedprefs.SaveList
import java.io.File
import java.util.*

/**
 * Le gestionnaire d'images
 * @author Jean-Emile PELLIER
 */
object PictureManager {
    // le dossier des images
    private val picDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "SpaceDynamics")
    // l'ensemble des identifiants connus (ordonnés selon l'ordre naturel)
    private val mLockedIds = TreeSet<Int>()
    // le prochain identifiant disponible
    var mNextAvailableId = 0
        get() {
            var expected = 1
            for (id in mLockedIds) if(id == expected) expected++
            return expected
        }
        private set

    init {
        // vérifie le contenu du dossier des images uniquement à l'instanciation du singleton
        checkDirectory()
    }

    /**
     * Vérifie le contenu du dossier des images
     */
    private fun checkDirectory() {
        picDir.apply {
            if (!exists() && !mkdirs()) {
                // le dossier n'existe pas et sa création n'est pas permise
                Logd("failed to create directory")
                return
            }
        }
        checkFiles()
    }

    /**
     * Vérifie la conformité des fichiers dans le dossier des images
     */
    private fun checkFiles() {
        for (file in picDir.listFiles()) {
            // isole le nom du fichier à partir du chemin canonique
            val filename = file.canonicalPath.substringAfterLast('/').substringBeforeLast('.')
            try {
                val photoId = filename.toInt()
                if(checkLink(photoId)) mLockedIds.add(photoId)
                else throw Exception()
            } catch(e: Exception) {
                // supprime le fichier si son nom n'est pas un nombre entier ou s'il n'est lié à aucune sauvegarde
                file.delete()
                Logd("file deleted: ${file.canonicalPath}")
            }
        }
    }

    /**
     * Vérifie qu'un identifiant est bien utilisé par une sauvegarde
     * @param photoId l'identifiant d'une photo
     * @return vrai si l'identiant est utilisé, faux sinon
     */
    private fun checkLink(photoId: Int): Boolean {
        val saveList = SaveList.toArrayList<Save>()
        for (save in saveList) if (save.photoId == photoId) return true
        return false
    }

    /**
     * Récupère un fichier image à partir de son identifiant
     * @param id l'identifiant de l'image
     * @return le fichier image correspondant à l'identifiant
     */
    fun getPicture(id: Int): File? = File("${picDir.canonicalPath}/$id.jpg")
}