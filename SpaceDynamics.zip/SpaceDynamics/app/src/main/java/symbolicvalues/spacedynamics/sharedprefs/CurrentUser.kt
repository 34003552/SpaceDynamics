package symbolicvalues.spacedynamics.sharedprefs

import android.content.Context
import com.google.android.gms.maps.model.LatLng
import symbolicvalues.spacedynamics.SpaceDynamics
import symbolicvalues.spacedynamics.core.GridPoint
import symbolicvalues.spacedynamics.core.Save
import symbolicvalues.spacedynamics.core.Score
import java.util.*

/**
 * Les données partagées relatives à l'utilisateur courant
 * @author Jean-Emile PELLIER
 */
object CurrentUser {
    // les préférences partagées associées à 'CurrentUser'
    private val mSettings = SpaceDynamics.mContext.getSharedPreferences("CurrentUser", Context.MODE_PRIVATE)
    // le nom de l'utilisateur
    var mName: String
        get() = mSettings.getString("name","")
        set(s) = mSettings.edit().putString("name", s).apply()
    // le temps de l'utilisateur
    var mTime: Long
        get() = mSettings.getLong("time",0L)
        set(l) = mSettings.edit().putLong("time", l).apply()
    // la position réelle de l'utilisateur
    var mLocation: LatLng
        get() = LatLng(
            mSettings.getString("latitude","${Double.NaN}").toDouble(),
            mSettings.getString("longitude","${Double.NaN}").toDouble()
        )
        set(ll) {
            mSettings.edit().putString("latitude", "${ll.latitude}").apply()
            mSettings.edit().putString("longitude", "${ll.longitude}").apply()
        }
    // la position des balles dans la partie courante
    var mBallsLocation: ArrayList<GridPoint>
        get() {
            val arr = ArrayList<GridPoint>()
            var i = 0
            while (mSettings.contains("ball_${i}x") && mSettings.contains("ball_${i}y")) {
                arr.add(
                    GridPoint(
                        mSettings.getFloat("ball_${i}x",Float.NaN),
                        mSettings.getFloat("ball_${i}y",Float.NaN)
                    )
                )
                i++
            }
            return arr
        }
        set(bla) {
            bla.forEachIndexed { i, gp ->
                mSettings.edit().putFloat("ball_${i}x", gp.x).apply()
                mSettings.edit().putFloat("ball_${i}y", gp.y).apply()
            }
        }
    // l'indice du niveau courant
    var mLevelIndex: Int
        get() = mSettings.getInt("level", 0)
        set(s) = mSettings.edit().putInt("level", s).apply()
    // l'identifiant de la photo associée à l'utilisateur courant
    var mPhotoId: Int
        get() = mSettings.getInt("photo", 0)
        set(p) = mSettings.edit().putInt("photo", p).apply()

    /**
     * Détruit les données de l'utilisateur courant
     */
    fun clear() = mSettings.edit().clear().apply()

    /**
     * Sauvegarde certaines données courantes vers un nouveau score
     */
    fun backupToScore() = ScoreList.add(Score(mTime, mName, Calendar.getInstance().time, mLocation))

    /**
     * Sauvegarde certaines données courantes vers une nouvelle sauvegarde
     */
    fun backupToSave() = SaveList.add(Save(mPhotoId, mName, Calendar.getInstance().time, mTime, mLevelIndex, mBallsLocation))

    /**
     * Restaure une partie à partir d'une sauvegarde
     * @param save une sauvegarde
     */
    fun restoreFrom(save: Save) {
        mPhotoId = save.photoId
        mName = save.nickname!!
        mTime = save.time
        mLocation = LatLng(Double.NaN,Double.NaN)
        mLevelIndex = save.levelIndex
        mBallsLocation = save.ballsLocation
    }
}