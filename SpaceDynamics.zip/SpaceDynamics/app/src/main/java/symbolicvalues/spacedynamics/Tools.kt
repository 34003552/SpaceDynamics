package symbolicvalues.spacedynamics

import android.util.Log

/**
 * Un ensemble d'outils destinés à toutes les classes
 * @author Jean-Emile PELLIER
 */


/**
 * Une fonction de log affichant le nom de la classe appelante
 * @param msg un message à afficher
 */
fun Any.Logd(msg: String) = Log.d(this::class.java.simpleName, msg)