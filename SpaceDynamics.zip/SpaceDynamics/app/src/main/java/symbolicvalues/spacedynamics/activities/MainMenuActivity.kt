package symbolicvalues.spacedynamics.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.managers.*

/**
 * L'activité du menu principal
 * @author Jean-Emile PELLIER
 */
class MainMenuActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var mButtonNewGame: Button
    private lateinit var mButtonLoadGame: Button
    private lateinit var mButtonShowScores: Button
    private lateinit var mButtonQuit: Button

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        mButtonNewGame = findViewById(R.id.buttonNewGame)
        mButtonLoadGame = findViewById(R.id.buttonLoadGame)
        mButtonShowScores = findViewById(R.id.buttonShowScores)
        mButtonQuit = findViewById(R.id.buttonQuit)

        mButtonNewGame.setOnClickListener(this)
        mButtonLoadGame.setOnClickListener(this)
        mButtonShowScores.setOnClickListener(this)
        mButtonQuit.setOnClickListener(this)
    }

    /**
     * Méthode appelée lors d'un appui sur une vue
     * @param view la vue sur laquelle l'appui a été effectué
     */
    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonNewGame -> this@MainMenuActivity.toPlayGameActivity()
            R.id.buttonLoadGame -> this@MainMenuActivity.toLoadGameActivity()
            R.id.buttonShowScores -> this@MainMenuActivity.toShowScoresActivity()
            R.id.buttonQuit -> System.exit(0)
        }
    }
}