package symbolicvalues.spacedynamics.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.managers.toCameraActivity
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser

/**
 * L'activité de sauvegarde de la partie
 * @author Jean-Emile PELLIER
 */
class SaveGameActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var mEditTextUsername: EditText
    private lateinit var mButtonTakePhoto: Button
    private lateinit var mButtonSave: Button
    private lateinit var mButtonBack: Button

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_game)

        mEditTextUsername = findViewById(R.id.editTextUsername)
        mButtonTakePhoto = findViewById(R.id.buttonTakePhoto)
        mButtonSave = findViewById(R.id.buttonSave)
        mButtonBack = findViewById(R.id.buttonBack)

        // définit le texte par défaut du champ de texte
        mEditTextUsername.setText(CurrentUser.mName)
        // déclenche un écouteur pour un changement de valeur dans le champ de texte
        mEditTextUsername.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // modifie le nom associé à la partie
                CurrentUser.mName = s.toString()
            }
            override fun afterTextChanged(s: Editable) {}
        })

        mButtonTakePhoto.setOnClickListener(this)
        mButtonSave.setOnClickListener(this)
        mButtonBack.setOnClickListener(this)
    }

    /**
     * Méthode appelée lors d'un appui sur une vue
     * @param view la vue sur laquelle l'appui a été effectué
     */
    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonTakePhoto -> this@SaveGameActivity.toCameraActivity()
            R.id.buttonSave -> {
                // sauvegarde la partie
                CurrentUser.backupToSave()
                Toast.makeText(applicationContext, R.string.game_saved, Toast.LENGTH_SHORT).show()
            }
            R.id.buttonBack -> finish()
        }
    }
}