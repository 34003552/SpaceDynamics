package symbolicvalues.spacedynamics.activities

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Camera
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import symbolicvalues.spacedynamics.Logd
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.managers.PictureManager
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser
import java.io.File
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException

/**
 * L'activité de la caméra
 * @author Jean-Emile PELLIER
 */
class CameraActivity : AppCompatActivity() {
    private lateinit var mCameraPreviewLayout: FrameLayout
    private lateinit var mButtonCapture: Button

    // la caméra
    private var mCamera: Camera? = try { Camera.open() } catch (e: Exception) { null }
    // la surface de prévisualisation
    private var mPreview: CameraPreview? = null

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)

        // vérifie l'existence de la fonctionnalité caméra
        if (!applicationContext.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            Toast.makeText(this@CameraActivity, R.string.no_camera, Toast.LENGTH_SHORT).show()
            finish()
        }

        mCameraPreviewLayout = findViewById(R.id.camera_preview)
        mButtonCapture = findViewById(R.id.button_capture)

        // construit la vue de prévisualisation
        mPreview = mCamera?.let { CameraPreview(this@CameraActivity) }
        // définit cette vue comme étant le contenu de l'activité
        mPreview?.also { mCameraPreviewLayout.addView(it) }
        // définit l'action du bouton de capture
        mButtonCapture.setOnClickListener {
            // récupère l'image à partir de la caméra
            mCamera?.takePicture(null, null, Camera.PictureCallback { data, _ ->
                val nextAvailableId = PictureManager.mNextAvailableId
                val pictureFile: File = PictureManager.getPicture(nextAvailableId) ?: run {
                    Logd("error creating media file, check storage permissions")
                    return@PictureCallback
                }

                try {
                    val fos = FileOutputStream(pictureFile)
                    fos.write(data)
                    fos.close()
                }
                catch (e: FileNotFoundException) { Logd("file not found: ${e.message}") }
                catch (e: IOException) { Logd("error accessing file: ${e.message}") }

                // référence le fichier image dans la partie de l'utilisateur courant
                CurrentUser.mPhotoId = nextAvailableId
                // termine l'activité
                finish()
            })
        }
    }

    /**
     * Méthode appelée lors de la mise en pause de l'activité
     */
    override fun onPause() {
        super.onPause()
        // verrouille la camera pour une utilisation ultérieure
        mCamera?.lock()
    }

    /**
     * Méthode appelée lors de la destruction de l'activité
     */
    override fun onDestroy() {
        super.onDestroy()
        // libère la caméra
        mCamera?.release()
        mCamera = null
    }

    /**
     * La surface de prévisualisation de la caméra
     * @param context le contexte dans lequel se trouve la vue
     * @param attrs les attributs d'inflate
     * @param defStyle un attribut dans le thème courant
     */
    private inner class CameraPreview @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
    ) : SurfaceView(context, attrs, defStyle), SurfaceHolder.Callback {

        // un possesseur de surface
        private val mHolder: SurfaceHolder? = holder.apply {
            addCallback(this@CameraPreview)
            // paramètre obsolète mais requis sur les versions d'Android inférieures à 3.0
            setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS)
        }

        /**
         * Méthode appelée lors de la création de la surface
         * @param holder le possesseur de la surface
         */
        override fun surfaceCreated(holder: SurfaceHolder) {

            mCamera!!.apply {
                try {
                    setPreviewDisplay(holder)
                    startPreview()
                } catch (e: IOException) { Logd("error setting camera preview: ${e.message}") }
            }
        }

        /**
         * Méthode appelée lors de la destruction de la surface
         * @param holder le possesseur de la surface
         */
        override fun surfaceDestroyed(holder: SurfaceHolder) { }

        /**
         * Méthode appelée lors d'un changement sur la surface
         * @param holder le possesseur de la surface
         * @param format le nouveau format de pixel de la surface
         * @param w la nouvelle largeur de la surface
         * @param h la nouvelle hauteur de la surface
         */
        override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            // ignore le changement si la surface n'existe pas
            if (mHolder?.surface == null) return

            // interrompt la prévisualisation avant d'effectuer une modification
            try { mCamera!!.stopPreview() } catch (e: Exception) { }

            // traite le changement d'orientation
            // ???

            // démarre la prévisualisation avec les nouveaux paramètres
            mCamera!!.apply {
                try {
                    setPreviewDisplay(mHolder)
                    startPreview()
                } catch (e: Exception) { Logd("error starting camera preview: ${e.message}") }
            }
        }
    }
}