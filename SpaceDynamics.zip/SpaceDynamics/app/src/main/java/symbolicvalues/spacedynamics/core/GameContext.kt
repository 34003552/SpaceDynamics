package symbolicvalues.spacedynamics.core

import android.graphics.Canvas
import symbolicvalues.spacedynamics.Logd
import symbolicvalues.spacedynamics.graphics.GridCircle
import symbolicvalues.spacedynamics.managers.OrientationManager
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser

/**
 * Un contexte de jeu
 * @author Jean-Emile PELLIER
 * @property mGrid la grille
 * @property mLevel le niveau de jeu
 */
class GameContext(private val mGrid: Grid, private val mLevel: Level) {
    // vrai si le contexte est terminé, faux sinon
    var isFinished = false
        private set

    /**
     * Déplace les balles jouables
     * @param roll le paramètre roll
     * @param pitch le paramètre pitch
     */
    private fun movePlayableBalls(roll: Float, pitch: Float) {
        for(pb in mLevel.playableBalls) {
            // ignore le déplacement d'une balle si celle-ci est verrouillée
            if(pb.mIsLocked) continue
            // récupère un point de grille dans la grille correspondant à la translation par roll et pitch
            pb.mLocation = mGrid.getValidGridPoint(pb.mLocation.x+roll, pb.mLocation.y+pitch)
        }
    }

    // les différents modes de collision : toucher, chute et capture
    enum class CollisionMode { TOUCH, FALL, CAPTURE }

    /**
     * Vérifie la présence d'une collision entre deux cercles de la grille
     * @param gc1 le cercle de grille 1
     * @param gc2 le cercle de grille 2
     * @param mode le mode de collision
     * @return vrai s'il y a collision, faux sinon
     */
    private fun hasCollisionBetween(gc1: GridCircle, gc2: GridCircle, mode: CollisionMode): Boolean {
        // la distance entre deux points d'une même grille
        val d = mGrid.getDistanceBetween(gc1.mLocation, gc2.mLocation)
        // l'angle pour gc1 par rapport à gc2
        val angle12 = mGrid.getAngleBetween(gc1.mLocation, gc2.mLocation)
        // l'angle pour gc2 par rapport à gc1
        val angle21 = mGrid.getAngleBetween(gc2.mLocation, gc1.mLocation)
        // rayons des ellipses d'axes (boxWidth, boxHeight)
        val ellipticalRadius1 = mGrid.getEllipticalRadius(angle12)
        val ellipticalRadius2 = mGrid.getEllipticalRadius(angle21)
        // le décalage à rajouter pour identifier ce type de collision
        val offset = when(mode) {
            CollisionMode.TOUCH -> 0
            CollisionMode.FALL -> mGrid.mBoxWidth/2
            CollisionMode.CAPTURE -> mGrid.mBoxWidth
        }
        // l'état d'existence de la collision
        val result = mGrid.mBoxWidth*(d+offset) < mGrid.mBoxHeight*(gc1.mRadius*ellipticalRadius1+gc2.mRadius*ellipticalRadius2)
        if(result) Logd("angles: $angle12,$angle21")
        return result
    }

    // les balles jouables restantes
    private var mRemainingBalls = mLevel.playableBalls.size

    /**
     * Teste toutes les collisions
     * @param roll le paramètre roll
     * @param pitch le paramètre pitch
     */
    private fun testCollisions(roll: Float, pitch: Float) {
        // teste les collisions impliquant les balles qui n'ont pas encore atteint leur objectif
        for(pb1 in mLevel.playableBalls) if (!pb1.mHasFinished) {
            // teste les collisions entre deux balles jouables
            for(pb2 in mLevel.playableBalls) if(pb1 != pb2 && hasCollisionBetween(pb1, pb2, CollisionMode.TOUCH)) {
                Logd("collision ($pb1, $pb2) -> nothing to do")
            }
            // teste les collisions entre une balle et un trou blanc
            for(pb2 in mLevel.whiteHoles) if(hasCollisionBetween(pb1, pb2, CollisionMode.TOUCH)) {
                Logd("collision ($pb1, $pb2) -> $pb1 bounces")
                pb1.mLocation = GridPoint(pb1.mLocation.x-roll*pb2.mRadius*10, pb1.mLocation.y-pitch*pb2.mRadius*10)
            }
            // teste les collisions entre une balle et un trou noir
            for(pb2 in mLevel.blackHoles) if(hasCollisionBetween(pb1, pb2, CollisionMode.FALL)) {
                Logd("collision ($pb1, $pb2) -> $pb1 reset its location")
                pb1.resetLocation()
            }
            // teste les collisions entre une balle et un cercle de destination de même couleur
            for(pb2 in mLevel.destinationCircles) if(pb1.mColor == pb2.mColor && hasCollisionBetween(pb1, pb2, CollisionMode.CAPTURE)) {
                Logd("collision ($pb1, $pb2) -> $pb1 reaches its goal")
                // verrouille le mouvement de la balle pour effectuer une animation
                if(!pb1.mIsLocked) pb1.mIsLocked = true
                if(Math.round(pb1.mLocation.x*100)/100.0f == pb2.mLocation.x && Math.round(pb1.mLocation.y*100)/100.0f == pb2.mLocation.y) {
                    pb1.mHasFinished = true
                    mRemainingBalls--
                    // vérifie qu'il existe encore des balles n'ayant pas atteint leur objectif
                    if(mRemainingBalls == 0) {
                        // met fin au contexte de jeu
                        isFinished = true
                        return
                    }
                }
                else {
                    // démarre l'animation de capture de la balle par son cercle de destination
                    pb1.mLocation = GridPoint(pb1.mLocation.x+0.1f*(pb2.mLocation.x-pb1.mLocation.x), pb1.mLocation.y+0.1f*(pb2.mLocation.y-pb1.mLocation.y))
                }
            }
        }
    }

    /**
     * Procède à l'éxécution du contexte de jeu
     */
    fun proceed() {
        val o = OrientationManager.mCurrentOrientation
        // déplace les balles jouables selon l'inclinaison de l'appareil mobile
        movePlayableBalls(o.roll, o.pitch)
        // teste toutes les collisions
        testCollisions(o.roll, o.pitch)
    }

    /**
     * Mémorise le statut courant du contexte de jeu
     */
    fun backupStatus() {
        val ballsLocation = ArrayList<GridPoint>()
        mLevel.playableBalls.forEach { pb -> ballsLocation.add(pb.mLocation) }
        CurrentUser.mBallsLocation = ballsLocation
    }

    /**
     * Restaure le statut du contexte de jeu
     */
    fun restoreStatus() {
        val ballsLocation = CurrentUser.mBallsLocation
        // vérifie que les positions des balles sont pertinentes
        if (ballsLocation.size < mLevel.playableBalls.size) {
            // réinitialise les positions
            mLevel.playableBalls.forEach { pb -> pb.resetLocation() }
        } else {
            // restaure les positions précédentes
            mLevel.playableBalls.forEachIndexed { i, pb -> pb.mLocation = ballsLocation[i] }
        }
    }

    /**
     * Dessine le contexte de jeu
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    fun draw(canvas: Canvas, x: Int, y: Int, width: Int, height: Int) {
        // dessine à partir de l'itération sur la concaténation des éléments graphiques actuels
        arrayOf(*mLevel.blackHoles, *mLevel.playableBalls, *mLevel.whiteHoles, *mLevel.destinationCircles).forEach {
            val p = mGrid.getOnScreenCoordinatesOf(it.mLocation)
            it.draw(canvas, p.x, p.y, mGrid.mBoxWidth, mGrid.mBoxHeight)
        }
    }
}