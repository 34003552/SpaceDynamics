package symbolicvalues.spacedynamics

import android.app.Application

/**
 * L'application SpaceDynamics
 * @author Jean-Emile PELLIER
 */
class SpaceDynamics : Application() {

    companion object {
        // le contexte d'application (accessible à toutes les classes)
        lateinit var mContext: Application
            private set
    }

    /**
     * Méthode appelée lors de la création de l'application
     */
    override fun onCreate() {
        super.onCreate()
        // définit le contexte d'application
        mContext = this@SpaceDynamics

        Logd("application created")
    }
}