package symbolicvalues.spacedynamics.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.core.Score
import symbolicvalues.spacedynamics.sharedprefs.ScoreList

/**
 * L'activité de visualisation de cartes
 * @author Jean-Emile PELLIER
 */
class MapsActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    private lateinit var mMap: GoogleMap

    /**
     * Méthode appelée lors d'un appui sur un marqueur
     * @param p0 le marqueur sur lequel l'appui a été effectué
     */
    override fun onMarkerClick(p0: Marker?) = false

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        // démarre l'attente de la notification signalant une carte prête à l'usage
        mapFragment.getMapAsync(this)
    }

    /**
     * Méthode appelée lorsque la carte est prête à être utilisée
     * @param googleMap une instance de GoogleMap associée à MapFragment
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerClickListener(this)

        // récupère la liste des scores
        val scores = ScoreList.toArrayList<Score>()
        // récupère le score depuis l'activité précédente
        val selectedScore = intent.getIntExtra("selectedScore", 0)

        var selectedLocation: LatLng? = LatLng(Double.NaN, Double.NaN)
        scores.forEachIndexed { i, score ->
            val marker = MarkerOptions().position(score.location!!).title(score.nickname!!)
            if(i == selectedScore) {
                // modifie la couleur du marqueur associé au score sélectionné
                marker.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                // définit la position sélectionnée à partir du score sélectionné
                selectedLocation = score.location
            }
            // place un marqueur
            mMap.addMarker(marker)
        }
        // positionne la caméra sur la position sélectionnée
        mMap.moveCamera(CameraUpdateFactory.newLatLng(selectedLocation))
    }
}