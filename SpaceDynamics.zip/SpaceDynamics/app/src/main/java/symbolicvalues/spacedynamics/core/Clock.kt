package symbolicvalues.spacedynamics.core

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/**
 * Une horloge définie en tant qu'objet dynamique
 * @author Jean-Emile PELLIER
 * @param time le temps initial de l'horloge
 */
class Clock @JvmOverloads constructor(time: Long = 0L) : DynamicObject() {
    // la valeur courante de l'horloge
    @Volatile var mTime = time
        private set

    companion object {
        /**
         * Formatte le temps
         * @param time un temps
         * @return le temps formatté correspondant à 'time'
         */
        fun format(time: Long): String {
            val (h, m, s) = Triple((time / (60 * 60)) % 24,(time / 60) % 60,time % 60)

            return if(h == 0L) {
                if(m == 0L) String.format("%02d", s)
                else String.format("%02d:%02d", m, s)
            } else String.format("%d:%02d:%02d", h, m, s)
        }
    }

    /**
     * La boucle d'évènement de l'horloge
     */
    override fun loop() {
        Thread.sleep(1000)
        mTime++
    }

    private val mPaint = Paint()

    /**
     * La méthode de dessin de l'horloge
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    fun draw(canvas: Canvas, x: Int, y: Int, width: Int, height: Int) {
        // paramètre le dessin
        mPaint.color = Color.YELLOW
        mPaint.textSize = 20.0f
        mPaint.textAlign = Paint.Align.CENTER
        mPaint.setShadowLayer(8.0f,0.0f,0.0f, Color.WHITE)
        // dessine le texte
        canvas.drawText(format(mTime), x+0.0f, y-height/2+20.0f, mPaint)
    }
}