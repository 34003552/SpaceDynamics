package symbolicvalues.spacedynamics.core

import android.graphics.*
import symbolicvalues.spacedynamics.activities.PlayGameActivity
import symbolicvalues.spacedynamics.managers.toEndGameActivity
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser

/**
 * Le moteur de jeu défini en tant qu'objet dynamique
 * @author Jean-Emile PELLIER
 * @property mGameBoardView la vue du plateau de jeu
 */
class GameEngine(private val mGameBoardView: PlayGameActivity.GameBoardView) : DynamicObject() {
    // l'activité liée à la vue du plateau de jeu
    private val mPlayGameActivity = mGameBoardView.context as PlayGameActivity
    // la grille
    private val mGrid = Grid()
    // l'horloge
    private val mClock = Clock(CurrentUser.mTime)
    // l'indice du niveau courant
    private var mLevelIndex = CurrentUser.mLevelIndex
    // le contexte de jeu courant
    private var mGameContext = GameContext(mGrid, mLevels[mLevelIndex])
    // le délai de rafraichissement de la vue du plateau de jeu
    private val mDelay = 20L

    /**
     * La boucle d'éxécution du moteur de jeu
     */
    override fun loop() {
        // délègue le travail au contexte de jeu courant
        mGameContext.proceed()
        // identifie la fin du contexte de jeu courant
        if (mGameContext.isFinished) {
            mLevelIndex++
            // vérifie l'existence d'un niveau suivant
            if (mLevelIndex >= mLevels.size) {
                // termine la partie
                mPlayGameActivity.toEndGameActivity()
                return
            } else {
                // passe au niveau suivant
                mGameContext = GameContext(mGrid, mLevels[mLevelIndex])
            }
        }
        // ralentit le thread
        Thread.sleep(mDelay)
        // rafraichit l'écran
        mGameBoardView.postInvalidate()
    }

    /**
     * Démarre le moteur de jeu
     */
    override fun start() {
        super.start()
        // démarre l'horloge
        mClock.start()
    }

    /**
     * Met en pause le moteur de jeu
     */
    override fun pause() {
        super.pause()
        // met en pause l'horloge
        mClock.pause()
        // sauvegarde temporairement l'état d'une partie
        CurrentUser.mTime = mClock.mTime
        CurrentUser.mLevelIndex = mLevelIndex
        mGameContext.backupStatus()
    }

    /**
     * Relance le moteur de jeu
     */
    override fun resume() {
        super.resume()
        // relance l'horloge
        mClock.resume()
        mGameContext.restoreStatus()
    }

    /**
     * Interrompt le moteur de jeu
     */
    override fun stop() {
        super.stop()
        // interrompt l'horloge
        mClock.stop()
    }

    /**
     * Dessine le moteur de jeu
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    fun draw(canvas: Canvas, x: Int, y: Int, width: Int, height: Int) {
        // dessine la grille
        mGrid.draw(canvas, x, y, width, height)
        // dessine le contexte de jeu
        mGameContext.draw(canvas, x, y, width, height)
        // dessine l'horloge
        mClock.draw(canvas, x, y, width, height)
    }
}