package symbolicvalues.spacedynamics.core

import com.google.android.gms.maps.model.LatLng
import java.util.*

/**
 * Un ensemble de classes de stockage
 * @author Jean-Emile PELLIER
 */

/**
 * Une structure pour contenir une orientation
 * @property azimuth le paramètre azimut
 * @property pitch le paramètre pitch
 * @property roll le paramètre roll
 */
data class Orientation(val azimuth: Float, val pitch: Float, val roll: Float)

/**
 * Une structure pour contenir un point de grille
 * @property x la position sur l'axe des abscisses
 * @property y la position sur l'axe des ordonnées
 */
data class GridPoint(val x: Float, val y: Float) {
    constructor(cx: Number, cy: Number) : this(cx.toFloat(), cy.toFloat())
}

/**
 * Une entité ordonnable
 */
open class Orderable {
    // le rang de l'entité ordonnable
    var rank: Int = 0
}

/**
 * Une structure pour contenir une sauvegarde
 * @property photoId l'identifiant d'une photo
 * @property nickname le pseudo
 * @property date la date
 * @property time le temps de jeu
 * @property levelIndex l'indice du niveau de jeu
 * @property ballsLocation la localisation des balles jouables
 */
data class Save(
    var photoId: Int,
    var nickname: String?,
    var date: Date?,
    var time: Long,
    var levelIndex: Int,
    var ballsLocation: ArrayList<GridPoint>
) : Orderable()

/**
 * Une structure pour contenir un score
 * @property time le temps de jeu
 * @property nickname le pseudo
 * @property date la date
 * @property location la position géographique
 */
data class Score(
    var time: Long,
    var nickname: String?,
    var date: Date?,
    var location: LatLng?
) : Orderable()