package symbolicvalues.spacedynamics.core

import android.graphics.Color
import symbolicvalues.spacedynamics.graphics.*

/**
 * L'ensemble des niveaux du jeu
 * @author Jean-Emile PELLIER
 */

/**
 * Une structure pour contenir un niveau de jeu
 * @property playableBalls les balles jouables
 * @property whiteHoles les trous blancs
 * @property blackHoles les trous noirs
 * @property destinationCircles les cercles de destination
 */
class Level(
    val playableBalls: Array<PlayableBall>,
    val whiteHoles: Array<WhiteHole>,
    val blackHoles: Array<BlackHole>,
    val destinationCircles: Array<DestinationCircle>
)

// la liste des niveaux de jeu
val GameEngine.mLevels: Array<Level>
    get() = arrayOf(
        // le niveau 0
        Level(
            arrayOf(
                PlayableBall(GridPoint(0, Grid.LIMIT_TOP - 1), Color.RED)
            ),
            arrayOf(
                WhiteHole(GridPoint(Grid.LIMIT_LEFT / 2, 0)),
                WhiteHole(GridPoint(Grid.LIMIT_RIGHT / 2, 0))
            ),
            arrayOf(
                BlackHole(GridPoint(0, 0))
            ),
            arrayOf(
                DestinationCircle(GridPoint(0, Grid.LIMIT_BOTTOM + 1), Color.RED)
            )
        ),
        // le niveau 1
        Level(
            arrayOf(
                PlayableBall(GridPoint(Grid.LIMIT_LEFT + 1, Grid.LIMIT_TOP - 1), Color.RED),
                PlayableBall(GridPoint(Grid.LIMIT_RIGHT - 1, Grid.LIMIT_TOP - 1), Color.BLUE)
            ),
            arrayOf(
                WhiteHole(GridPoint(0, 0))
            ),
            arrayOf(
                BlackHole(GridPoint(Grid.LIMIT_LEFT + 2, 0)),
                BlackHole(GridPoint(Grid.LIMIT_RIGHT - 2, 0))
            ),
            arrayOf(
                DestinationCircle(GridPoint(Grid.LIMIT_LEFT + 1, Grid.LIMIT_BOTTOM + 1), Color.RED),
                DestinationCircle(GridPoint(Grid.LIMIT_RIGHT - 1, Grid.LIMIT_BOTTOM + 1), Color.BLUE)
            )
        ),
        // le niveau 2
        Level(
            arrayOf(
                PlayableBall(GridPoint(Grid.LIMIT_LEFT + 1, Grid.LIMIT_TOP - 1), Color.RED),
                PlayableBall(GridPoint(0, Grid.LIMIT_TOP - 1), Color.GREEN),
                PlayableBall(GridPoint(Grid.LIMIT_RIGHT - 1, Grid.LIMIT_TOP - 1), Color.BLUE)
            ),
            arrayOf(
                WhiteHole(GridPoint(0, 0))
            ),
            arrayOf(
                BlackHole(GridPoint(Grid.LIMIT_LEFT + 1, Grid.LIMIT_TOP / 3)),
                BlackHole(GridPoint(Grid.LIMIT_RIGHT - 1, Grid.LIMIT_TOP / 3)),
                BlackHole(GridPoint(Grid.LIMIT_LEFT / 2, Grid.LIMIT_BOTTOM / 2)),
                BlackHole(GridPoint(Grid.LIMIT_RIGHT / 2, Grid.LIMIT_BOTTOM / 2))
            ),
            arrayOf(
                DestinationCircle(GridPoint(Grid.LIMIT_LEFT + 1, Grid.LIMIT_BOTTOM + 1), Color.RED),
                DestinationCircle(GridPoint(0, Grid.LIMIT_BOTTOM + 1), Color.GREEN),
                DestinationCircle(GridPoint(Grid.LIMIT_RIGHT - 1, Grid.LIMIT_BOTTOM + 1), Color.BLUE)
            )
        )
    )