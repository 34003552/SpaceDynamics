package symbolicvalues.spacedynamics.activities

import android.content.Context
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.core.Clock
import symbolicvalues.spacedynamics.core.Score
import symbolicvalues.spacedynamics.managers.toMapsActivity
import symbolicvalues.spacedynamics.sharedprefs.ScoreList
import java.text.SimpleDateFormat
import java.util.*

/**
 * L'activité de visualisation des scores
 * @author Jean-Emile PELLIER
 */
class ShowScoresActivity : AppCompatActivity() {
    private lateinit var mListViewScores: ListView

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_scores)

        mListViewScores = findViewById(R.id.listViewScores)

        // récupère la liste des scores
        val scoreList = ScoreList.toArrayList<Score>()
        // définit l'adaptateur pour la vue listViewScores
        mListViewScores.adapter = ScoreAdapter(this@ShowScoresActivity, scoreList)
    }

    /**
     * L'adaptateur de scores
     * @param context le contexte courant
     * @param scores la liste des scores
     */
    private inner class ScoreAdapter(context: Context, scores: ArrayList<Score>) : ArrayAdapter<Score>(context, 0, scores) {

        /**
         * Récupère la vue qui affiche le score
         * @param position la position de la vue dans la liste
         * @param convertView l'ancienne vue à réutiliser
         * @param parent le parent éventuel auquel la vue est rattachée
         */
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val convertView = convertView ?: LayoutInflater.from(context).inflate(R.layout.row_score, parent, false)

            // mémorise le contenu de la vue
            val viewHolder = convertView!!.tag as ScoreViewHolder? ?: ScoreViewHolder(
                rank = convertView.findViewById(R.id.rank),
                score = convertView.findViewById(R.id.score),
                nickname = convertView.findViewById(R.id.nickname),
                date = convertView.findViewById(R.id.date),
                locate = convertView.findViewById(R.id.locate),
                erase = convertView.findViewById(R.id.erase)
            )
            convertView.tag = viewHolder

            // récupère le score à une position donnée
            val score = getItem(position)

            // place un écouteur d'évènement sur le bouton localiser
            viewHolder.locate!!.setOnClickListener { this@ShowScoresActivity.toMapsActivity(position) }

            // place un écouteur d'évènement sur le bouton effacer
            viewHolder.erase!!.setOnClickListener {
                remove(score)
                ScoreList.remove(score)
            }

            // met à jour le contenu de la vue
            viewHolder.rank!!.text = score.rank.toString()
            viewHolder.score!!.text = Clock.format(score.time)
            viewHolder.nickname!!.text = score.nickname
            viewHolder.date!!.text = SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(score.date)

            return convertView
        }

        /**
         * Le possesseur de la vue de sauvegarde
         * @property rank le texte du rang
         * @property score le texte du score
         * @property nickname le texte du pseudo
         * @property date le texte de la date
         * @property load le bouton de localisation
         * @property erase le bouton d'effacement
         */
        private inner class ScoreViewHolder(
            var rank: TextView? = null,
            var score: TextView? = null,
            var nickname: TextView? = null,
            var date: TextView? = null,
            var locate: Button? = null,
            var erase: Button? = null
        )
    }
}