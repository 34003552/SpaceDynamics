package symbolicvalues.spacedynamics.core

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Point

/**
 * Une grille de jeu
 * @author Jean-Emile PELLIER
 */
class Grid {
    companion object {
        // les dimensions fixes de la grille
        const val LIMIT_TOP = 10
        const val LIMIT_LEFT = -10
        const val LIMIT_RIGHT = 10
        const val LIMIT_BOTTOM = -10
    }

    // vrai si la grille doit être visible, faux sinon
    private val mVisibility = false

    // la largeur d'une case de la grille
    val mBoxWidth: Int
        get() = mWidth / (LIMIT_RIGHT - LIMIT_LEFT)
    // la hauteur d'une case de la grille
    val mBoxHeight: Int
        get() = mHeight / (LIMIT_TOP - LIMIT_BOTTOM)

    /**
     * Récupère un point de grille qui se situe dans la grille
     * @param x la coordonnée horizontale d'un point de grille
     * @param y la coordonnée verticale d'un point de grille
     * @return un point de grille se trouvant dans la grille
     */
    fun getValidGridPoint(x: Float, y: Float): GridPoint {
        val nx: Float = when {
            x < Grid.LIMIT_LEFT -> Grid.LIMIT_LEFT.toFloat()
            x > Grid.LIMIT_RIGHT -> Grid.LIMIT_RIGHT.toFloat()
            else -> x
        }
        val ny: Float = when {
            y > Grid.LIMIT_TOP -> Grid.LIMIT_TOP.toFloat()
            y < Grid.LIMIT_BOTTOM -> Grid.LIMIT_BOTTOM.toFloat()
            else -> y
        }
        return GridPoint(nx, ny)
    }

    /**
     * Renvoie la distance entre deux points de grille
     * @param a le point A
     * @param b le point B
     * @return la distance entre A et B
     */
    fun getDistanceBetween(a: GridPoint, b: GridPoint): Double {
        val dx = mBoxWidth * (a.x - b.x).toDouble()
        val dy = mBoxHeight * (a.y - b.y).toDouble()
        return Math.sqrt(dx * dx + dy * dy)
    }

    /**
     * Renvoie l'angle entre deux points de grille
     * @param a le point A
     * @param b le point B
     * @return l'angle entre A et B
     */
    fun getAngleBetween(a: GridPoint, b: GridPoint): Double {
        return 2 * Math.atan((a.y - b.y).toDouble()/((a.x - b.x).toDouble() + getDistanceBetween(a, b)))
    }

    /**
     * Renvoie le rayon de l'ellipse unitaire en fonction de l'angle
     * @param t l'angle selon lequel calculer le rayon
     * @return le rayon correspondant à l'angle t
     */
    fun getEllipticalRadius(t: Double): Double {
        return Math.sqrt(mBoxWidth*mBoxWidth*Math.cos(t)*Math.cos(t)+mBoxHeight*mBoxHeight*Math.sin(t)*Math.sin(t))
    }

    /**
     * Renvoie l'équivalent d'un point de grille dans le plan de dessin
     * @param gp un point de grille
     * @return un point équivalent à 'gp' dans le plan de dessin
     */
    fun getOnScreenCoordinatesOf(gp: GridPoint) = Point((mX + gp.x * mBoxWidth).toInt(), (mY - gp.y * mBoxHeight).toInt())

    /**
     * Renvoie l'équivalent d'un point dans le plan de la grille
     * @param p un point
     * @return un point de grille équivalent à 'p' dans la grille
     */
    fun getOnGridCoordinatesOf(p: Point) = GridPoint((p.x - mX) / mBoxWidth, -(p.y - mY) / mBoxHeight)

    // la coordonnée centrale de la zone de dessin suivant l'axe horizontal
    var mX: Int = 0
        private set
    // la coordonnée centrale de la zone de dessin suivant l'axe vertical
    var mY: Int = 0
        private set
    // la largeur de la zone de dessin
    var mWidth: Int = 0
        private set
    // la hauteur de la zone de dessin
    var mHeight: Int = 0
        private set

    private val mPaint = Paint()

    /**
     * Fixe la position et la dimension de la grille puis la dessine si elle est visible
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    fun draw(canvas: Canvas?, x: Int, y: Int, width: Int, height: Int) {
        // fixe les dimensions de la grille
        mX = x
        mY = y
        mWidth = width
        mHeight = height

        // empêche le dessin de la grille si celle-ci n'est pas visible
        if(!mVisibility) return

        val (begGridX, begGridY) = Pair(x - width/2.0f, y + height/2.0f)
        val (midGridX, midGridY) = Pair(1.0f*x, 1.0f*y)
        val (endGridX, endGridY) = Pair(x + width/2.0f, y - height/2.0f)

        // dessine les axes
        mPaint.color = Color.WHITE
        canvas?.drawLine(begGridX, midGridY, endGridX, midGridY, mPaint)
        canvas?.drawLine(midGridX, begGridY, midGridX, endGridY, mPaint)
        // dessine l'origine
        mPaint.color = Color.MAGENTA
        canvas?.drawCircle(midGridX, midGridY,5.0f, mPaint)
        // dessine le quadrillage
        mPaint.color = Color.GRAY
        for(i in 1 until LIMIT_TOP+1) canvas?.drawLine(begGridX, midGridY-i*mBoxHeight, endGridX, midGridY-i*mBoxHeight, mPaint)
        for(i in 1 until -LIMIT_BOTTOM+1) canvas?.drawLine(begGridX, midGridY+i*mBoxHeight, endGridX, midGridY+i*mBoxHeight, mPaint)
        for(i in 1 until -LIMIT_LEFT+1) canvas?.drawLine(midGridX-i*mBoxWidth, begGridY, midGridX-i*mBoxWidth, endGridY, mPaint)
        for(i in 1 until LIMIT_RIGHT+1) canvas?.drawLine(midGridX+i*mBoxWidth, begGridY, midGridX+i*mBoxWidth, endGridY, mPaint)
    }
}