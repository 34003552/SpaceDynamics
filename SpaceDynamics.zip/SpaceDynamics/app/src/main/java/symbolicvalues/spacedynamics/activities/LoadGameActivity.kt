package symbolicvalues.spacedynamics.activities

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.core.Save
import symbolicvalues.spacedynamics.managers.PictureManager
import symbolicvalues.spacedynamics.managers.toPlayGameActivity
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser
import symbolicvalues.spacedynamics.sharedprefs.SaveList
import java.text.SimpleDateFormat
import java.util.*

/**
 * L'activité de chargement de parties
 * @author Jean-Emile PELLIER
 */
class LoadGameActivity : AppCompatActivity() {
    private lateinit var mListViewSaves: ListView

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_load_game)

        mListViewSaves = findViewById(R.id.listViewSaves)

        // récupère la liste des sauvegardes
        val saveList = SaveList.toArrayList<Save>()
        // définit l'adaptateur pour la vue listViewSaves
        mListViewSaves.adapter = SaveAdapter(this@LoadGameActivity, saveList)
    }

    /**
     * L'adaptateur de sauvegardes
     * @param context le contexte courant
     * @param saves la liste des sauvegardes
     */
    private inner class SaveAdapter(context: Context, saves: ArrayList<Save>?) : ArrayAdapter<Save>(context, 0, saves) {

        /**
         * Récupère la vue qui affiche la sauvegarde
         * @param position la position de la vue dans la liste
         * @param convertView l'ancienne vue à réutiliser
         * @param parent le parent éventuel auquel la vue est rattachée
         */
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val convertView = convertView ?: LayoutInflater.from(context).inflate(R.layout.row_save, parent, false)

            // mémorise le contenu de la vue
            val viewHolder = convertView!!.tag as SaveViewHolder? ?: SaveViewHolder(
                rank = convertView.findViewById(R.id.rank),
                photo = convertView.findViewById(R.id.photo),
                nickname = convertView.findViewById(R.id.nickname),
                date = convertView.findViewById(R.id.date),
                load = convertView.findViewById(R.id.load),
                erase = convertView.findViewById(R.id.erase)
            )
            convertView.tag = viewHolder

            // récupère la sauvegarde à une position donnée
            val save = getItem(position)

            // place un écouteur d'évènement sur le bouton charger
            viewHolder.load!!.setOnClickListener {
                CurrentUser.restoreFrom(save)
                this@LoadGameActivity.toPlayGameActivity()
            }

            // place un écouteur d'évènement sur le bouton effacer
            viewHolder.erase!!.setOnClickListener {
                remove(save)
                SaveList.remove(save)
            }

            // met à jour le contenu de la vue
            viewHolder.rank!!.text = save.rank.toString()
            if(save.photoId != 0) {
                viewHolder.photo!!.setImageURI(Uri.fromFile(PictureManager.getPicture(save.photoId)))
            }
            viewHolder.nickname!!.text = save.nickname
            viewHolder.date!!.text = SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(save.date)

            return convertView
        }

        /**
         * Le possesseur de la vue de sauvegarde
         * @property rank le texte du rang
         * @property photo l'image de la photo
         * @property nickname le texte du pseudo
         * @property date le texte de la date
         * @property load le bouton de chargement
         * @property erase le bouton d'effacement
         */
        private inner class SaveViewHolder(
            var rank: TextView? = null,
            var photo: ImageView? = null,
            var nickname: TextView? = null,
            var date: TextView? = null,
            var load: Button? = null,
            var erase: Button? = null
        )
    }
}