package symbolicvalues.spacedynamics.managers

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import symbolicvalues.spacedynamics.SpaceDynamics
import symbolicvalues.spacedynamics.core.Orientation

/**
 * Le gestionnaire d'orientations
 * @author Jean-Emile PELLIER
 */
class OrientationManager : SensorEventListener {
    // le gestionnaire de capteurs
    private val mSensorManager = SpaceDynamics.mContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager?
    // l'accéléromètre
    private val mAccelerometer: Sensor? = mSensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    // le magnétomètre
    private val mMagnetometer: Sensor? = mSensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    companion object {
        // l'orientation actuelle
        var mCurrentOrientation = Orientation(0.0f, 0.0f, 0.0f)
            private set
    }

    /**
     * La méthode appelée lors d'un changement de précision
     * @param sensor le capteur en cours de surveillance
     * @param accuracy la nouvelle précision du capteur
     */
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { }

    // les valeurs de l'accéléromètre
    private var mGravity : FloatArray? = null
    // les valeurs du champ magnétique
    private var mGeomagnetic : FloatArray? = null

    /**
     * La méthode appelée lors d'un changement de capteur
     * @param event l'évènement du capteur
     */
    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) mGravity = event.values
        if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) mGeomagnetic = event.values
        // attend l'initialisation des valeurs des capteurs par des appels successifs à la méthode courante
        if (mGravity != null && mGeomagnetic != null) {
            val (r, i) = Pair(FloatArray(9) { 0.0f }, FloatArray(9) { 0.0f })
            // récupère la matrice de rotation
            val success = SensorManager.getRotationMatrix(r, i, mGravity, mGeomagnetic)
            if (success) {
                val ori = FloatArray(3) { 0.0f }
                // récupère l'orientation
                SensorManager.getOrientation(r, ori)
                // paramètre l'ajustement des valeurs
                val (base, precision, step) = Triple(10.0,5.0,0.25f)
                // propose une fonction d'ajustement des valeurs
                val round = { n: Float -> step * ((n * Math.pow(base,precision)).toInt() / Math.pow(base,precision)).toFloat() }
                // stocke l'orientation dans un attribut statique
                mCurrentOrientation = Orientation(round(ori[0]), round(ori[1]), round(ori[2]))
            }
        }
    }

    /**
     * Enregistre les écouteurs du gestionnaire de capteur
     */
    fun registerListener() {
        mSensorManager?.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI)
        mSensorManager?.registerListener(this, mMagnetometer, SensorManager.SENSOR_DELAY_UI)
    }

    /**
     * Détruit les écouteurs du gestionnaire de capteur
     */
    fun unregisterListener() {
        mSensorManager?.unregisterListener(this)
    }
}