package symbolicvalues.spacedynamics.sharedprefs

import symbolicvalues.spacedynamics.core.GridPoint
import symbolicvalues.spacedynamics.core.Save
import java.lang.StringBuilder
import java.util.*

/**
 * La liste partagée contenant les sauvegardes
 * @author Jean-Emile PELLIER
 */
object SaveList : SharedList<Save>("SaveList",
    Comparator { s1, s2 ->
        if (s1.date != s2.date) -1 * s1.date!!.compareTo(s2.date!!)
        else s1.nickname!!.compareTo(s2.nickname!!)
    },
    Comparator { s1, s2 -> -1 * s1.date!!.compareTo(s2.date!!) }) {

    /**
     * Construit des données brutes à partir de données abstraites
     * @param data une donnée abstraite
     */
    override fun buildRawData(data: Save): String {
        val sb = StringBuilder()
        // ajoute l'identifiant de la photo
        sb.append("${data.photoId}\n")
        // ajoute le pseudo
        sb.append("${data.nickname}\n")
        // ajoute la date
        sb.append("${mDateFormat.format(data.date)}\n")
        // ajoute le temps de jeu
        sb.append("${data.time}\n")
        // ajoute l'indice du niveau de jeu
        sb.append("${data.levelIndex}\n")
        // ajoute la localisation des balles
        data.ballsLocation.forEach { bl -> sb.append("${bl.x},${bl.y}\n") }
        // assemble les données brutes
        return sb.toString()
    }

    /**
     * Construit des données abstraites à partir de données brutes
     * @param value une donnée brute
     */
    override fun parseRawData(data: String): Save {
        val scanner = Scanner(data)
        // récupère l'identifiant de la photo
        val photoId = scanner.nextLine()
        // récupère le pseudo
        val nickname = scanner.nextLine()
        // récupère la date
        val date = scanner.nextLine()
        // récupère le temps de jeu
        val time = scanner.nextLine()
        // récupère l'indice du niveau de jeu
        val levelIndex = scanner.nextLine()
        // récupère la position des balles
        val ballsLocation = ArrayList<GridPoint>()
        while (scanner.hasNextLine()) {
            val (x, y) = scanner.nextLine().split(',')
            ballsLocation.add(GridPoint(x.toFloat(), y.toFloat()))
        }

        scanner.close()
        // construit la sauvegarde
        return Save(photoId.toInt(), nickname, mDateFormat.parse(date), time.toLong(), levelIndex.toInt(), ballsLocation)
    }
}