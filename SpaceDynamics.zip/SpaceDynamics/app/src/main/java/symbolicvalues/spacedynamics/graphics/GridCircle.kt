package symbolicvalues.spacedynamics.graphics

import android.graphics.Canvas
import symbolicvalues.spacedynamics.core.GridPoint

/**
 * Un cercle de grille
 * @author Jean-Emile PELLIER
 * @property mLocation la position du cercle dans une grille
 * @property mColor la couleur du cercle
 * @property mRadius le rayon du cercle
 */
abstract class GridCircle(@Volatile var mLocation: GridPoint, val mColor: Int, val mRadius: Float) {

    /**
     * La méthode de dessin du cercle
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    abstract fun draw(canvas: Canvas?, x: Int, y: Int, width: Int, height: Int)
}