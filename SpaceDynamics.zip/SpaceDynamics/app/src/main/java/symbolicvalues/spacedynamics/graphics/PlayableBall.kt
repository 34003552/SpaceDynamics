package symbolicvalues.spacedynamics.graphics

import android.graphics.Canvas
import android.graphics.Paint
import symbolicvalues.spacedynamics.core.GridPoint

/**
 * Une balle jouable défini comme étant un cercle de grille
 * @author Jean-Emile PELLIER
 * @param location la position de la balle dans une grille
 * @param color la couleur de la balle
 * @param radius le rayon de la balle
 */
class PlayableBall(location: GridPoint, color: Int, radius: Float = 1.0f) : GridCircle(location, color, radius) {
    // la position initiale de la balle
    private val mInitialLocation = mLocation
    // vrai si la balle est verrouillée, faux sinon
    var mIsLocked = false
    // vrai si la balle a atteint sa destination, faux sinon
    var mHasFinished = false

    /**
     * Replace la balle à sa position initiale
     */
    fun resetLocation() {
        mLocation = mInitialLocation
    }

    private val mPaint = Paint()

    /**
     * La méthode de dessin de la balle
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    override fun draw(canvas: Canvas?, x: Int, y: Int, width: Int, height: Int) {
        // paramètre le dessin
        mPaint.color = mColor
        // définit les dimensions de la balle
        val dim = if (width > height) height else width
        // dessine la balle
        canvas?.drawCircle(x.toFloat(), y.toFloat(),mRadius * dim, mPaint)
    }
}