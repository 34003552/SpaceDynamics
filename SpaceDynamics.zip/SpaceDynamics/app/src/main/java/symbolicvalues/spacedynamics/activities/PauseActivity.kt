package symbolicvalues.spacedynamics.activities

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.managers.toMainMenuActivity
import symbolicvalues.spacedynamics.managers.toSaveGameActivity

/**
 * L'activité de pause
 * @author Jean-Emile PELLIER
 */
class PauseActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var mButtonResume: Button
    private lateinit var mButtonSave: Button
    private lateinit var mButtonBackToMainMenu: Button

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pause)

        mButtonResume = findViewById(R.id.buttonResume)
        mButtonSave = findViewById(R.id.buttonSave)
        mButtonBackToMainMenu = findViewById(R.id.buttonBackToMainMenu)

        mButtonResume.setOnClickListener(this)
        mButtonSave.setOnClickListener(this)
        mButtonBackToMainMenu.setOnClickListener(this)
    }

    /**
     * Méthode appelée lors d'un appui sur une vue
     * @param view la vue sur laquelle l'appui a été effectué
     */
    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonResume -> finish()
            R.id.buttonSave -> this@PauseActivity.toSaveGameActivity()
            R.id.buttonBackToMainMenu -> this@PauseActivity.toMainMenuActivity()
        }
    }
}