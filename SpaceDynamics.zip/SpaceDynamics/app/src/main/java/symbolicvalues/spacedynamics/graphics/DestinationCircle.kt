package symbolicvalues.spacedynamics.graphics

import android.graphics.Canvas
import android.graphics.Paint
import symbolicvalues.spacedynamics.core.GridPoint

/**
 * Un cercle de destination défini comme étant un cercle de grille
 * @author Jean-Emile PELLIER
 * @param location la position du cercle dans une grille
 * @param color la couleur du cercle
 * @param radius le rayon du cercle
 */
class DestinationCircle(location: GridPoint, color: Int, radius: Float = 2.0f) : GridCircle(location, color, radius) {

    private val mPaint = Paint()

    /**
     * La méthode de dessin du cercle de destination
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    override fun draw(canvas: Canvas?, x: Int, y: Int, width: Int, height: Int) {
        // paramètre le dessin
        mPaint.color = mColor
        mPaint.style = Paint.Style.STROKE
        // définit les dimensions du cercle
        val dim = if (width > height) height else width
        // dessine le cercle
        canvas?.drawCircle(x.toFloat(), y.toFloat(),mRadius * dim, mPaint)
    }
}