package symbolicvalues.spacedynamics.sharedprefs

import android.content.Context
import android.content.SharedPreferences
import symbolicvalues.spacedynamics.Logd
import symbolicvalues.spacedynamics.SpaceDynamics
import symbolicvalues.spacedynamics.core.Orderable
import java.text.SimpleDateFormat
import java.util.*

/**
 * Une liste ordonnée encapsulant les préférences partagées
 * @author Jean-Emile PELLIER
 * @param name le nom des préférences partagées à encapsuler
 * @param comparator le comparateur "strict"
 * @property mRankComparator le comparateur "souple"
 */
abstract class SharedList<T : Orderable> internal constructor(name: String, comparator: Comparator<T>, private val mRankComparator: Comparator<T>) {
    // les préférences partagées associées au nom 'name'
    private val mSettings: SharedPreferences = SpaceDynamics.mContext.getSharedPreferences(name, Context.MODE_PRIVATE)
    // l'ensemble ordonné des entrées de la liste
    protected val mOrderedList = TreeSet(comparator)

    companion object {
        // le format utilisé pour le stockage de la date
        val mDateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
    }

    init {
        // construit la liste
        for (element in mSettings.all) {
            try {
                // ajoute une entrée dans la liste
                mOrderedList.add(parseRawData(element.value as String))
            } catch(e: Exception) {
                // interception d'une entrée non conforme
                Logd("unable to parse ${element.key}\n${element.value}")
            }
        }
        // met à jour les rangs
        reorder()
    }

    /**
     * Met à jour les rangs dans la liste
     */
    private fun reorder() {
        var prev: T? = null
        mOrderedList.forEach { d ->
            if(prev == null) d.rank = 1
            else {
                // compare les données avec le comparateur de rang
                val cmp = mRankComparator.compare(prev,d)
                when {
                    cmp < 0  -> d.rank = prev!!.rank + 1
                    cmp == 0 -> d.rank = prev!!.rank
                    else -> throw RuntimeException("Unexpected behavior")
                }
            }
            prev = d
        }
    }

    /**
     * Construit des données brutes à partir de données structurées
     * @param data une donnée structurée
     */
    protected abstract fun buildRawData(data: T): String

    /**
     * Construit des données structurées à partir de données brutes
     * @param data une donnée brute
     */
    protected abstract fun parseRawData(data: String): T

    /**
     * Ajoute une entrée à la liste
     * @param data une entrée à ajouter
     */
    fun add(data: T) {
        val rawData = buildRawData(data)
        // annule l'ajout si le hash obtenu correspond déjà à une clé connue
        if(mSettings.contains("${rawData.hashCode()}")) return
        // ajoute la donnée aux préférences partagées
        mSettings.edit().putString("${rawData.hashCode()}", rawData).apply()
        // ajoute la donnée à la liste ordonnée
        mOrderedList.add(data)
        // met à jour les rangs dans la liste
        reorder()
    }

    /**
     * Efface une entrée de la liste
     * @param data une entrée à effacer
     */
    fun remove(data: T) {
        val rawSave = buildRawData(data)
        // annule la suppression si le hash obtenu ne correspond pas à une clé connue
        if(!mSettings.contains("${rawSave.hashCode()}")) return
        // supprime la donnée depuis les préférences partagées
        mSettings.edit().remove("${rawSave.hashCode()}").apply()
        // supprime la donnée depuis la liste ordonnée
        mOrderedList.remove(data)
        // met à jour les rangs dans la liste
        reorder()
    }

    /**
     * Détruit l'ensemble des entrées de la liste
     */
    fun clear() {
        // vide les préférences partagées
        mSettings.edit().clear().apply()
        // vide la liste ordonnée
        mOrderedList.clear()
    }

    /**
     * Convertit la liste vers un format plus facile à manipuler
     */
    @Suppress("UNCHECKED_CAST")
    inline fun <reified T> toArrayList(): ArrayList<T> = ArrayList(mOrderedList as TreeSet<T>)
}