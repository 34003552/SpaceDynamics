package symbolicvalues.spacedynamics.graphics

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import symbolicvalues.spacedynamics.core.GridPoint

/**
 * Un trou noir défini comme étant un cercle de grille
 * @author Jean-Emile PELLIER
 * @param location la position du trou noir dans une grille
 * @param radius le rayon du trou noir
 */
class BlackHole(location: GridPoint, radius: Float = 3.0f) : GridCircle(location, Color.BLACK, radius) {

    private val mPaint = Paint()

    /**
     * La méthode de dessin du trou noir
     * @param canvas le paramètre canvas
     * @param x la coordonnée centrale de la zone de dessin suivant l'axe horizontal
     * @param y la coordonnée centrale de la zone de dessin suivant l'axe vertical
     * @param width la largeur de la zone de dessin
     * @param height la hauteur de la zone de dessin
     */
    override fun draw(canvas: Canvas?, x: Int, y: Int, width: Int, height: Int) {
        // paramètre le dessin
        mPaint.color = mColor
        // définit les dimensions du trou blanc
        var dim = if (width > height) height else width
        // dessine le trou noir
        canvas?.drawCircle(x.toFloat(), y.toFloat(),mRadius * dim, mPaint)

        // paramètre le dessin
        mPaint.color = Color.GRAY
        mPaint.style = Paint.Style.STROKE
        // dessine les cercles concentriques
        while (dim != 0) {
            canvas?.drawCircle(x.toFloat(), y.toFloat(),mRadius * dim, mPaint)
            // redéfinit les dimensions des cercles concentriques
            dim /= 2
        }
    }
}