package symbolicvalues.spacedynamics.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import symbolicvalues.spacedynamics.R
import symbolicvalues.spacedynamics.managers.toMainMenuActivity
import symbolicvalues.spacedynamics.sharedprefs.CurrentUser
import symbolicvalues.spacedynamics.managers.GeolocationManager


/**
 * L'activité de fin de partie
 * @author Jean-Emile PELLIER
 */
class EndGameActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var mEditTextUsername: EditText
    private lateinit var mButtonSave: Button
    private lateinit var mButtonBack: Button

    // le gestionnaire de géolocalisation
    private lateinit var mGeolocationManager: GeolocationManager

    /**
     * Méthode appelée lors de la construction de l'activité
     * @param savedInstanceState l'état de l'instance sauvegardée
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end_game)

        mEditTextUsername = findViewById(R.id.editTextUsername)
        mButtonSave = findViewById(R.id.buttonSave)
        mButtonBack = findViewById(R.id.buttonBackToMainMenu)

        // définit le texte par défaut du champ de texte
        mEditTextUsername.setText(CurrentUser.mName)
        // déclenche un écouteur pour un changement de valeur dans le champ de texte
        mEditTextUsername.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // modifie le nom associé à la partie
                CurrentUser.mName = s.toString()
            }
            override fun afterTextChanged(s: Editable) {}
        })
        mButtonSave.setOnClickListener(this)
        mButtonBack.setOnClickListener(this)

        // initialise le gestionnaire de géolocalisation
        mGeolocationManager = GeolocationManager(this)
    }

    /**
     * Méthode appelée lors de la reprise de l'activité
     */
    override fun onResume() {
        super.onResume()
        // démarre les mises à jour de la position géographique
        mGeolocationManager.startLocationUpdates()
    }

    /**
     * Méthode appelée lors de la mise en pause de l'activité
     */
    override fun onPause() {
        super.onPause()
        // interrompt les mises à jour de la position géographique
        mGeolocationManager.stopLocationUpdates()
    }

    /**
     * Méthode appelée lors d'un résultat à une requête de permission
     * @param requestCode le code de requête
     * @param permissions les permissions
     * @param grantResults les résultats d'autorisation
     */
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        mGeolocationManager.checkPermissions(requestCode, permissions, grantResults)
    }

    /**
     * Méthode appelée lors d'un appui sur une vue
     * @param view la vue sur laquelle l'appui a été effectué
     */
    override fun onClick(view: View) {
        when (view.id) {
            R.id.buttonSave -> {
                // récupère la position courante
                CurrentUser.mLocation = GeolocationManager.mCurrentLocation
                // sauvegarde le score
                CurrentUser.backupToScore()
                Toast.makeText(applicationContext, R.string.score_saved, Toast.LENGTH_SHORT).show()
            }
            R.id.buttonBackToMainMenu -> this@EndGameActivity.toMainMenuActivity()
        }
    }
}