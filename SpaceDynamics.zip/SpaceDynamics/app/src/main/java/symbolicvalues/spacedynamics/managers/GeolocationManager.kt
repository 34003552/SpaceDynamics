package symbolicvalues.spacedynamics.managers

import android.app.Activity
import android.content.pm.PackageManager
import android.support.v4.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.android.gms.maps.model.LatLng
import symbolicvalues.spacedynamics.Logd

/**
 * Le gestionnaire de géolocalisation
 * @author Jean-Emile PELLIER
 * @property mActivity l'activité appelante
 */
class GeolocationManager(private val mActivity: Activity) {
    // le fournisseur de position
    private var mFusedLocationClient = LocationServices.getFusedLocationProviderClient(mActivity)
    // la requête de position
    private var mLocationRequest = LocationRequest()
    // la fonction de rappel pour récupérer la position
    private var mLocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult?) {
            val location = locationResult!!.lastLocation
            if (location != null) {
                // la position géographique est valide
                Logd("latitude: ${location.latitude}, longitude: ${location.longitude}")
                // stocke la position dans un attribut statique
                mCurrentLocation = LatLng(location.latitude, location.longitude)
            }
            else Logd("invalid user location")
        }
    }

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1

        // la position géographique courante
        var mCurrentLocation = LatLng(Double.NaN, Double.NaN)
            private set
    }

    /**
     * Démarre les mises à jour de la position
     */
    fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(mActivity, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // demande la permission
            ActivityCompat.requestPermissions(mActivity, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
        } else {
            // demande la mise à jour de la position
            try { mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null) }
            catch (e: SecurityException) { Logd("security error") }
        }
    }

    /**
     * Interrompt les mises à jour de la position
     */
    fun stopLocationUpdates() {
        mFusedLocationClient.removeLocationUpdates(mLocationCallback)
    }

    /**
     * Vérifie l'état des permissions pour la géolocalisation
     * @param requestCode le code de requête
     * @param permissions les permissions
     * @param grantResults les résultats d'autorisation
     */
    fun checkPermissions(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            LOCATION_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // demande la mise à jour de la position
                    try { mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, null) }
                    catch (e: SecurityException) { Logd("security error") }
                }
                return
            }
        }
    }
}